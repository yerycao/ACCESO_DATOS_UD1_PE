
package contadorpalabras;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author yeray
 */
public class ContadorPalabras {
    
    public static String contadorPalabras(String cadena){
        
        ArrayList<String> palabrasCopia = new ArrayList<String>();
        HashSet<String> palabras = new HashSet<String>();
        Iterator it;
        Scanner sc = new Scanner(cadena);
        int contador = 0;
        String resultado = "";
        
        while(sc.hasNext()){
            palabras.add(sc.next());
        }
        
        it = palabras.iterator();
        
        while(it.hasNext()){
            palabrasCopia.add((String) it.next());
        }
        
        for (int i = 0; i < palabrasCopia.size(); i++) {
            for (int j = 0; j < palabrasCopia.size(); j++) {
                
                if(palabrasCopia.get(i).equalsIgnoreCase(palabrasCopia.get(j)))
                    contador++;
            }
            
            resultado = resultado + palabrasCopia.get(i) + ": " + contador + "\n";
            contador = 0;
        }
        
        return resultado;
    }
    
    public static void main(String[] args) {
        
        String cadena;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Introduce la cadena");
        cadena = sc.nextLine();
        
        System.out.println(contadorPalabras(cadena));
    }
}
