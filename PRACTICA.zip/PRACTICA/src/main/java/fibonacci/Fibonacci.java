
package fibonacci;

/**
 *
 * @author yeray
 */
public class Fibonacci {
    
    public static void main(String[] args) {
        
        int anterior1 = 0, anterior2 = 0, resultado;
        
        for (int i = 0; i < 50; i++) {
            
            if(i == 0 || i == 1){
                System.out.print(i + ", ");
                anterior2 = anterior1;
                anterior1 = i;
            }
            else{
                System.out.print(anterior1 + anterior2 + ", ");
                resultado = anterior1 + anterior2;
                anterior2 = anterior1;
                anterior1 = resultado;
            }
            
            
        }
    }
}
