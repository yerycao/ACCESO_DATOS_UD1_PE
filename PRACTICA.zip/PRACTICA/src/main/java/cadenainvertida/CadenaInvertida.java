
package cadenainvertida;

import java.util.Scanner;

/**
 *
 * @author yeray
 */
public class CadenaInvertida {
    
    public static String invertirCadena(String cadena){
        
        String resultado = "";
        
        for (int i = cadena.length() - 1; i >= 0; i--) {
            
            resultado = resultado + cadena.charAt(i);
        }
        
        return resultado;
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        String cadena;
        
        System.out.println("Introduce la cadena a invertir");
        cadena = sc.nextLine();
        
        System.out.println(invertirCadena(cadena));
    }
}
