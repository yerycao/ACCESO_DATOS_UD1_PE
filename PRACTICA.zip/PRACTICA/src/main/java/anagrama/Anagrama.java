
package anagrama;

import java.util.Scanner;

/*
Crear una funcion que recibe 2 Strings y devuelve un boolean segun si las palabras son anagramas o no.
Un anagrama es cuando a raiz de las letras de una palabra, puedes formar otra palabra reordenando las letras de la primera
 */
public class Anagrama {
    
    public static boolean isAnagrama(String palabra1, String palabra2){
        int contador1 = 0, contador2 = 0, puntos = 0;
        if(palabra1.length() != palabra2.length() || palabra1.equals(palabra2)){
            return false;
        }
        for (int i = 0; i < palabra1.length(); i++) {
            for (int j = 0; j < palabra1.length(); j++) {
                if(palabra1.charAt(i) == palabra1.charAt(j))
                    contador1++;
            }
            for (int j = 0; j < palabra2.length(); j++) {
                if(palabra1.charAt(i) == palabra2.charAt(j))
                    contador2++;
            }
            if(contador1 == contador2){
                puntos++;
                contador1 = 0;
                contador2 = 0;
            }
            else
                return false;
        }
        return puntos == palabra1.length();
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        String palabra1, palabra2;
        
        System.out.println("Introduce la primera palabra: ");
        palabra1 = sc.nextLine();
        System.out.println("Introduce la segunda palabra: ");
        palabra2 = sc.nextLine();
        
        System.out.println(isAnagrama(palabra1, palabra2));
    }
}
