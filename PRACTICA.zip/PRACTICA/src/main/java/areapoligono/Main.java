
package areapoligono;

/**
 *
 * @author yeray
 */
public class Main {
    
    public static void main(String[] args) {
        Poligono triangulo = new Triangulo(10.0, 5.0);
        Poligono rectangulo = new Rectangulo(10.0, 5.0);
        Poligono cuadrado = new Cuadrado(7.0);
        
        System.out.println(triangulo.calcularArea());
        System.out.println(rectangulo.calcularArea());
        System.out.println(cuadrado.calcularArea());
    }
}
