
package numeroprimo;

/**
 *
 * @author yeray
 */
public class NumeroPrimo {
    
    public static void main(String[] args) {
        
        int cont = 0;
        
        for (int i = 1; i <= 100; i++) {
            for (int j = 1; j <= i; j++) {
                if(i % j == 0)
                    cont++;
            }
            if(cont == 1 || cont == 2)
                System.out.print(i + ", ");
            cont = 0;
        }
    }
    
}
