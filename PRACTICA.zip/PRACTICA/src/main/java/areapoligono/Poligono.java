
package areapoligono;

/**
 *
 * @author yeray
 */
public interface Poligono {
    
    public double calcularArea();
}
