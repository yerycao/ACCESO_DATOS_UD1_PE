
package decimalabinario;

import java.util.Scanner;

public class DecimalABinario {
    
    public static String DecimalToBinary(int numeroDecimal){
        
        String resultadoInvertido = "";
        StringBuilder resultadoCorrecto;
        
        
        if(numeroDecimal == 0)
            return "0";
        
        while(numeroDecimal >= 2){
            
            resultadoInvertido = resultadoInvertido  + (numeroDecimal % 2);
            
            numeroDecimal = numeroDecimal / 2;
        }
        
        resultadoInvertido = resultadoInvertido + "1";
        resultadoCorrecto = new StringBuilder(resultadoInvertido);
        
        return resultadoCorrecto.reverse().toString();
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int numeroDecimal;
        
        System.out.println("Introduce el numero en decimal");
        numeroDecimal = sc.nextInt();
        
        System.out.println(DecimalToBinary(numeroDecimal));
    }
}
